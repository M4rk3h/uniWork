import UIKit

class Scene2ViewController: NSObject {

}
